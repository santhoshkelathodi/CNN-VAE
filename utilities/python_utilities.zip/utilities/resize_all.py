# import the necessary packages
from __future__ import print_function
import numpy as np
import argparse
import cv2
import os
import shutil

fullpath = os.path.join
start_directory = "."
cat_directory = "./cat"
dog_directory = "./dog"
dest_directory = "./resized"

def resize_all_images():
    for dirname, dirnames, filenames in os.walk(start_directory):
        for filename in filenames:
            source = fullpath(dirname, filename)
	    destpart = fullpath(dest_directory, source.split('/')[1])
            dest = fullpath(destpart, filename)
            if (source.startswith("./Class")):
	    	print(dirname)
            	print(source)
		print(dest)
		img = cv2.imread(source)
		factor = 8
		newx,newy = img.shape[1]/factor,img.shape[0]/factor #new size (w,h)
		newimage = cv2.resize(img,(newx,newy))
		cv2.imshow("img", img)
		cv2.imshow("newimage",newimage)
		cv2.waitKey(1)
		cv2.imwrite(dest, newimage)

if __name__ == "__main__":
    resize_all_images()

