import cv2

image = cv2.imread('example.jpg')
hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
h, s, v = cv2.split(hsv_image)

#s.fill(255)
#v.fill(255)
hsv_image = cv2.merge([h, s, v])

image[:,:,:] = 0
hsv_image[:,:,:] = 0
print h.shape
#cv2.imshow('h', h)
#cv2.imshow('s', s)
#cv2.imshow('v', v)
#cv2.imshow('image', image)



imageWidth = hsv_image.shape[1] #Get image width
imageHeight = hsv_image.shape[0] #Get image height
print imageWidth
print imageHeight
xPos, yPos = 0, 0
colorHue = 0
print hsv_image.shape
hsv_image[:,:,1] = 255
hsv_image[:,:,2] = 255
while xPos < imageWidth: #Loop through rows
    hsv_image[:,xPos,0] = colorHue
    xPos = xPos + 1 #Increment X position by 1
    colorHue = colorHue + 1
    if (colorHue == 180):
	break;

#convert to BGR
image = cv2.cvtColor(hsv_image, cv2.COLOR_HSV2BGR)
cv2.imshow('imagecolorgradient', image)
#cv2.imwrite("result.bmp", hsv_image) #Write image to file

cv2.waitKey()
