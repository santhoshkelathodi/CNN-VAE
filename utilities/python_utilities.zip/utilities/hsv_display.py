import cv2

image = cv2.imread('example.jpg')
hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
h, s, v = cv2.split(hsv_image)

#s.fill(255)
#v.fill(255)
hsv_image = cv2.merge([h, s, v])

cv2.imshow('h', h)
cv2.imshow('s', s)
cv2.imshow('v', v)
orig_image = cv2.cvtColor(hsv_image, cv2.COLOR_HSV2BGR)
cv2.imshow('orig_image', orig_image)
ret, mask = cv2.threshold(v, 15, 255, cv2.THRESH_BINARY)
cv2.imshow('mask', mask)
# Now black-out the area of logo in ROI
h_modified = cv2.bitwise_and(h,h,mask = mask)
s_modified = cv2.bitwise_and(s,s,mask = mask)
v_modified = cv2.bitwise_and(v,v,mask = mask)

cv2.imshow('h_modified', h_modified)
cv2.imshow('s_modified', s_modified)
cv2.imshow('v_modified', v_modified)

hsv_image_reconstruct = cv2.merge([h, s, v])

cv2.imshow('hsv_image_reconstruct', hsv_image_reconstruct)
#cv2.imshow('img_masked', img_masked)

cv2.imwrite("example_h.jpg",h)
cv2.imwrite("example_s.jpg",s)
cv2.imwrite("example_v.jpg",v)
cv2.imwrite("example_h__.jpg",orig_image)
cv2.waitKey()
