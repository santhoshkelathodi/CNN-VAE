# import the necessary packages
from __future__ import print_function
import numpy as np
import argparse
import cv2
import os
import shutil

fullpath = os.path.join
start_directory = "."
#dest_directory = "./sampled"
#os.remove() will remove a file.

def resize_all_images():
    for dirname, dirnames, filenames in os.walk(start_directory):
        for filename in filenames:
            source = fullpath(dirname, filename)
	    #destpart = fullpath(dest_directory, source.split('/')[1])
            #dest = fullpath(destpart, filename)
            #if (source.startswith("./Class")):
	    if (source.endswith(".jpg")):
	    	#print(dirname)
            	#print(source)
		#print(dest)
		#print(destpart)
		length = len(filename.split('.'))
		#print(length)
                if (3 == length):
	            print(source)
		    os.remove(source)

if __name__ == "__main__":
    resize_all_images()

#filepart1 = filename.split('.')[0]
#filepart2 = filename.split('.')[1]
#filepart3 = filename.split('.')[2]
#filepart4 = filename.split('.')[3]
#print(filepart1)
#print(filepart2)
#print(filepart3)
#newfilename = filepart1+"."+filepart2+".jpg"
#print(newfilename)
#newfilepath = fullpath(dirname, newfilename)
#print(newfilepath)
#os.remove(newfilepath)
