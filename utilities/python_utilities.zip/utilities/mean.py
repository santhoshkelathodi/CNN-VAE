from __future__ import print_function
import numpy as np


myList = [[70, 80, 90], [30, 40, 50]]
print (np.mean(myList, axis=0))
print (np.std(myList, axis=0))
