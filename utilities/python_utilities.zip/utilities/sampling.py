
import sys
import math
import numpy as np

def downsample(t, level, maxlevel):
    midIdx = len(t)/2
    print("length", len(t))
    if level == maxlevel:
        mylist = []
	#mylist.append(midElement)
	print("end condition", np.array(mylist)) 
        return np.array(mylist)
    midElement = t[midIdx]
    if len(t) == 1:
        mylist = []
	mylist.append(midElement)
        return np.array(mylist)
    if len(t) == 2:
        mylist = []
	arr2 = downsample(t[midIdx+1:], level+1, maxlevel)
        return np.concatenate(([midElement],arr2), axis = 0)
    else:
        mylist = []
	arr1 = downsample(t[:midIdx],level+1, maxlevel)
        midarr = np.concatenate((arr1, [midElement]), axis = 0)
	arr2 = downsample(t[midIdx+1:], level+1, maxlevel)

        return np.concatenate((midarr, arr2), axis = 0)

if __name__ == "__main__":
    inputsize = 90
    t = np.arange(inputsize)
    #print (t)
    a = t[:9]
    b = t[9:]
    #print np.concatenate((a, b), axis=0)
    resamplesize = 64
    maxlevel = int(math.log(resamplesize,2))
    first = []
    last = []
    #first.append(0)
    #last.append(inputsize-1)
    #sys.setrecursionlimit(10000)
    downsampled =  downsample(t, 0, maxlevel)
    print (downsampled)
    print ("add first element and last element to the list always: You will always get a sample to the size of a multiple of 2 + 1 with this approach")
    #print (np.random.uniform(-1,0,1000))
