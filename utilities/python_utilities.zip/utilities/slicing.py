import numpy as np
dat = np.loadtxt( '0.txt')

x = dat[:,0].astype( np.float )  # this is the F column as float
y = dat[:,1].astype( np.float )  # this is the T column as float
#print x
#print y
print len(x)
x_slice = x[::2]
y_slice = y[::2]
print len(x_slice)
#print x_reverse
np.savetxt('0_ano_4.txt', np.transpose([x_slice, y_slice]), fmt='%-3.4f', delimiter=' ')
