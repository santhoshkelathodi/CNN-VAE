import numpy as np
dat = np.loadtxt( '0.txt')

x = dat[:,0].astype( np.float )  # this is the F column as float
y = dat[:,1].astype( np.float )  # this is the T column as float
#print x
#print y
x_reverse = x[::-1]
y_reverse = y[::-1]

#print x_reverse
np.savetxt('0_ano_3.txt', np.transpose([x_reverse, y_reverse]), fmt='%-3.4f', delimiter=' ')
