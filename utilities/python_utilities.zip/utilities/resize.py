'''
$ python adjust_gamma.py --image example_01.png
'''
# import the necessary packages
from __future__ import print_function
import numpy as np
import argparse
import cv2

# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True,
	help="path to input video")
args = vars(ap.parse_args())
 
# Step 1 - Get previous to current frame transformation (dx, dy, da) for all frames
img = cv2.imread(args["image"])
factor = 2
newx,newy = img.shape[1]/2,img.shape[0]/2 #new size (w,h)
newimage = cv2.resize(img,(newx,newy))
cv2.imshow("img", img)
cv2.imshow("newimage",newimage)

cv2.waitKey(0)

cv2.imwrite("resized_"+args["image"], newimage)

