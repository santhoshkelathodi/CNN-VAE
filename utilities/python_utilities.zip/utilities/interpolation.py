import numpy as np

dat = np.loadtxt( '0.txt')

x = dat[:,0].astype( np.float )  # this is the F column as float
y = dat[:,1].astype( np.float )  # this is the T column as float

N = len(x)
X = np.arange(0, 2*N, 2)
X_new = np.arange(2*N-1)       # Where you want to interpolate
x_new = np.interp(X_new, X, x) 
y_new = np.interp(X_new, X, y) 

print len(y_new)
np.savetxt('0_ano_5.txt', np.transpose([x_new, y_new]), fmt='%-3.4f', delimiter=' ')
